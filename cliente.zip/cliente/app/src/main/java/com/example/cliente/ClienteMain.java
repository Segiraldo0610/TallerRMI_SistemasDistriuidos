package com.example.cliente;

import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;

import library.BibliotecaServiceGrpc;
import library.ConsultarReq;
import library.ConsultarRes;

public class ClienteMain {
  public static void main(String[] args) {
    if (args.length < 2) {
      System.out.println("Uso: mvn exec:java -Dexec.args=\"IP_SERVIDOR 50051\"");
      return;
    }

    String host = args[0];
    int port = Integer.parseInt(args[1]);

    ManagedChannel channel = ManagedChannelBuilder.forAddress(host, port)
        .usePlaintext()
        .build();

    BibliotecaServiceGrpc.BibliotecaServiceBlockingStub stub =
        BibliotecaServiceGrpc.newBlockingStub(channel);

    // Prueba simple: consulta un ISBN del seed del servidor
    ConsultarRes res = stub.consultar(
        ConsultarReq.newBuilder().setIsbn("9780307474278").build()
    );

    System.out.println("Existe: " + res.getExiste());
    System.out.println("Mensaje: " + res.getMensaje());
    System.out.println("Titulo: " + res.getTitulo());

    channel.shutdown();
  }
}
